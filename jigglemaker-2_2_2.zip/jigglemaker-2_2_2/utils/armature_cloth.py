import bpy

# --- JM: apply selected preset to cloth settings (for proxy & mirrored proxy) ---
import os as _os, ast as _ast, re as _re2


def _jm_preset_dirs():
    try:
        p = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
        return [p] if p else []
    except Exception:
        return []


def _jm_find_cloth_preset_path(name: str):
    if not name:
        return None
    for base in _jm_preset_dirs():
        fp = _os.path.join(base, f"{name}.py")
        if _os.path.exists(fp):
            return fp
    return None

def _jm_apply_preset_to_settings(settings, preset_name: str):
    if not preset_name:
        return 0, 0
    path = _jm_find_cloth_preset_path(preset_name)
    if not path or not _os.path.exists(path):
        return 0, 0
    applied = 0
    skipped = 0
    line_re = _re2.compile(r"""^\s*bpy\.context\.cloth\.settings\.([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$""")
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                m = line_re.match(line)
                if not m:
                    continue
                attr = m.group(1)
                raw = m.group(2).split('#',1)[0].strip()
                try:
                    val = _ast.literal_eval(raw)
                except Exception:
                    try:
                        v = float(raw); val = int(v) if v.is_integer() else v
                    except Exception:
                        skipped += 1; continue
                try:
                    setattr(settings, attr, val); applied += 1
                except Exception:
                    skipped += 1; continue
    except Exception:
        return 0, 0

    try:
        if not getattr(settings, "vertex_group_mass", ""):
            settings.vertex_group_mass = "Pin"
    except Exception:
        pass

    return applied, skipped
# -------------------------------------------------------------------------------

def apply_scale_bind_armature(proxy, mesh, armature_obj):
    if armature_obj is None or proxy is None:
        return

    # Clear action/keyframes ONLY if animation data exists
    ad = getattr(proxy, "animation_data", None)
    if ad:
        action = getattr(ad, "action", None)
        if action:
            _clear_action_keyframes_compat(action)

        # Unlink action from this datablock
        try:
            ad.action = None
        except Exception:
            pass

        # Blender 4.4+ / 5.x may also have action_slot; clear if present
        if hasattr(ad, "action_slot"):
            try:
                ad.action_slot = None
            except Exception:
                pass

    # Ensure proxy is active for ops that require an active object
    bpy.ops.object.select_all(action='DESELECT')
    proxy.select_set(True)
    bpy.context.view_layer.objects.active = proxy

    # Apply transforms
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    # Parent proxy to armature (this is what you need for armature deformation)
    bpy.ops.object.select_all(action='DESELECT')
    armature_obj.select_set(True)
    proxy.select_set(True)
    bpy.context.view_layer.objects.active = armature_obj

    bpy.ops.object.parent_set(type='ARMATURE_NAME')

    # Move the Armature modifier to the top if it exists
    bpy.context.view_layer.objects.active = proxy
    try:
        bpy.ops.object.modifier_move_to_index(modifier="Armature", index=0)
    except Exception:
        pass


def _clear_action_keyframes_compat(action):
    """Clear all keyframes from an Action (Blender 4.x legacy + Blender 5.x layered/slotted)."""
    if action is None:
        return

    # Blender 4.x legacy API
    if hasattr(action, "fcurves"):
        for fcurve in action.fcurves:
            fcurve.keyframe_points.clear()
        return

    # Blender 5.x layered/slotted API:
    # action.layers[*].strips[*].channelbags[*].fcurves[*]
    layers = getattr(action, "layers", None)
    if not layers:
        return

    for layer in layers:
        for strip in getattr(layer, "strips", []):
            # Newer API exposes channelbags collection directly
            channelbags = getattr(strip, "channelbags", None)
            if channelbags is not None:
                for cb in channelbags:
                    for fcurve in getattr(cb, "fcurves", []):
                        fcurve.keyframe_points.clear()
            else:
                # Fallback: try per-slot lookup if available
                slots = getattr(action, "slots", [])
                channelbag_fn = getattr(strip, "channelbag", None)
                if channelbag_fn:
                    for slot in slots:
                        cb = channelbag_fn(slot)
                        if cb:
                            for fcurve in getattr(cb, "fcurves", []):
                                fcurve.keyframe_points.clear()


def add_cloth_settings(obj, pin_group_name, preset='OPTION1'):
    # Make sure the target object is active and has a Cloth modifier
    bpy.context.view_layer.objects.active = obj
    if not any(m.type == 'CLOTH' for m in obj.modifiers):
        bpy.ops.object.modifier_add(type='CLOTH')
    cloth = next((m for m in obj.modifiers if m.type == 'CLOTH'), None)
    settings = cloth.settings

    # 1) Apply Blender cloth preset if a named preset is selected
    # (i.e., not our two internal OPTION1/OPTION2 placeholders)
    try:
        if preset and preset not in {'OPTION1', 'OPTION2'}:
            _jm_apply_preset_to_settings(settings, preset)
    except Exception:
        pass

    # 2) Always set the pin group LAST so the preset can’t overwrite it
    try:
        if pin_group_name:
            cloth.settings.vertex_group_mass = pin_group_name
    except Exception:
        pass

    # 3) Fallback only if still empty: ensure there is a "Pin" group and use it
    try:
        if not getattr(settings, "vertex_group_mass", ""):
            vg = obj.vertex_groups.get("Pin") or obj.vertex_groups.new(name="Pin")
            cloth.settings.vertex_group_mass = vg.name
    except Exception:
        pass
