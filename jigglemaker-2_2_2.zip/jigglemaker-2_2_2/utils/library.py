import bpy
from . import paths

_model_names_cache = []

def refresh_model_names():
    global _model_names_cache
    _model_names_cache.clear()
    lib_path = paths.presets_path()
    try:
        with bpy.data.libraries.load(lib_path, link=False) as (data_from, data_to):
            data_to.objects = data_from.objects
        for obj in data_to.objects:
            if obj and getattr(obj, "type", None) == 'MESH':
                _model_names_cache.append(obj.name)
            if obj is not None:
                mesh_data = getattr(obj, "data", None)
                bpy.data.objects.remove(obj, do_unlink=True)
                if mesh_data and mesh_data.users == 0 and not getattr(mesh_data, "use_fake_user", False):
                    bpy.data.meshes.remove(mesh_data)
    except Exception as e:
        print(f"[JiggleMaker] Error refreshing library: {e}")

def model_names():
    if not _model_names_cache:
        refresh_model_names()
    return list(_model_names_cache)

# --- JM: transform warning helpers (Armature via Main's modifier) ---
def _jm_get_armature_from_main(main_obj):
    """Return the armature object referenced by the first Armature modifier on main_obj."""
    if not main_obj or main_obj.type != 'MESH':
        return None
    for m in getattr(main_obj, "modifiers", []):
        if m.type == 'ARMATURE' and getattr(m, "object", None):
            return m.object
    return None

def _jm_has_applied_trs(o, eps=1e-5):
    """True if Location=(0,0,0), Rotation=(0,0,0), Scale=(1,1,1) within epsilon."""
    if not o:
        return True
    try:
        loc_ok = all(abs(v) <= eps for v in o.location[:])
        rot = getattr(o, "rotation_euler", None)
        rot_ok = True if rot is None else all(abs(v) <= eps for v in rot[:])
        scl_ok = all(abs(v - 1.0) <= eps for v in o.scale[:])
        return loc_ok and rot_ok and scl_ok
    except Exception:
        return True  # fail-safe

def _jm_draw_trs_warning(layout, main_obj):
    """Draw a red warning box if Main mesh or its Armature (from modifier) has unapplied transforms."""
    arm = _jm_get_armature_from_main(main_obj)
    offenders = []
    if main_obj and not _jm_has_applied_trs(main_obj):
        offenders.append(main_obj.name)
    if arm and not _jm_has_applied_trs(arm):
        offenders.append(arm.name)
    if offenders:
        box = layout.box()
        try:
            box.alert = True  # Blender 3.6+ red highlight
        except Exception:
            pass
        col = box.column(align=True)
        col.label(text="Transforms not applied!", icon='ERROR')
        col.label(text="Jiggle mesh will not bind properly.")
        col.label(text="Apply Location/Rotation/Scale on: " + ", ".join(offenders))
        col.label(text="Use Object Mode → Ctrl+A → All Transforms to apply all transforms")
        col.label(text="OR Use Object Mode → Alt+G/R/S to reset the transforms")
        return True
    return False
# --- JM: end helpers ---
# --- JM: size warning helper (Z dimension in meters) ---
def _jm_draw_size_warning(layout, main_obj, minimum=0.05, maximum=1):
    """Show a red error box if Z dimension is outside [0.5 m, 5.0 m]."""
    if not main_obj:
        return False
    try:
        z = float(getattr(main_obj, "dimensions", (0.0, 0.0, 0.0))[2])
    except Exception:
        return False  # fail-safe: don't block UI

    if z > maximum or z < minimum:
        box = layout.box()
        try:
            box.alert = True  # red highlight (Blender 3.6+)
        except Exception:
            pass
        col = box.column(align=True)
        col.label(text="Unrealistic jiggle mesh size", icon='ERROR')
        col.label(text="Jiggle mesh phyiscs might not work properly on unrealistic body sizes and may explode with default physics.")
        col.label(text=f"Jiggle mesh Z dimension is {z:.2f} m (expected 0.05–1 m).")
        return True
    return False
# --- JM: end size helper ---

def RemoveAllModifiersExceptArmature(obj):
    for modifier in obj.modifiers:
        if modifier.type != 'ARMATURE':
            obj.modifiers.remove(modifier)
    return obj


def _jm_object_has_collision(obj) -> bool:
    """Return True if object has a Collision physics modifier."""
    if not obj or obj.type != 'MESH':
        return False

    for mod in obj.modifiers:
        if mod.type == 'COLLISION':
            return True
    return False


def _jm_draw_collision_warning(layout, main_obj):
    """
    Draw a red warning box if Main mesh has a Collision modifier.
    Collision meshes can break jiggle / cloth binding.
    """
    offenders = []

    if _jm_object_has_collision(main_obj):
        offenders.append(main_obj.name)

    if offenders:
        box = layout.box()
        try:
            box.alert = True  # Blender 3.6+ red highlight
        except Exception:
            pass

        col = box.column(align=True)
        col.label(text=f"Collision modifier detected on {offenders}!", icon='ERROR')
        col.label(text="Collision meshes can break jiggle binding.")
        col.label(text="Remove Collision on:")
        col.label(text=", ".join(offenders))
        col.separator()
        col.label(text="Physics → Collision → Remove (X)")
        col.label(text="(Use a separate collision mesh instead,")
        col.label(text="by dublicating the mesh part where you need collision)")

        return True

    return False
