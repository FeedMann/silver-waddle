import bpy

class ClothBakePanel(bpy.types.Panel):
    bl_label = "Cloth Bake Admin"
    bl_idname = "JIGGLE_MAKER_PT_cloth_bake_admin"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JM"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.use_property_split = True
        layout.use_property_decorate = False

        # =========================
        # Global Controls (Header)
        # =========================
        head = layout.box()
        row = head.row(align=True)
        row.label(text="Global", icon='WORLD')

        bake = head.column(align=False)
        bake.use_property_split = False
        r = bake.row(align=False)
        r.operator("wm.jm_bake_cloth_selected", text="Bake Selected", icon='REC')
        r.operator("wm.jm_bake_cloth_selected_modal", text="Background Bake Selected ", icon='TIME')
        r=bake.row()
        r.operator("wm.jm_free_bake_cloth_selected", text="Free Bake", icon='TRASH')

        # ===============
        # Bake Range
        # ===============
        rbox = layout.box()
        rbox.label(text="Bake Range", icon='SEQUENCE')
        r = rbox.row(align=True)
        r.use_property_split = False
        r.prop(scene, "jm_bake_use_range", text="Custom Range", toggle=True, icon='ARROW_LEFTRIGHT')
        if getattr(scene, "jm_bake_use_range", False):
            r = rbox.row(align=True)
            r.use_property_split = False
            r.prop(scene, "jm_bake_start", text="Start")
            r.prop(scene, "jm_bake_end", text="End")

        # =====================
        # Early exit if empty
        # =====================
        if not getattr(scene, "jm_cloth_targets", None) or len(scene.jm_cloth_targets) == 0:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="No cloth objects found.", icon='INFO')
            col.label(text="Click Refresh to scan the scene.")
            col.operator("wm.jm_refresh_cloth_targets", text="Refresh", icon='FILE_REFRESH')
            return



        # ======================================================
        # Build: Surface Deform target -> list of user objects
        # ======================================================
        users_by_target = {}
        try:
            for ob in bpy.data.objects:
                for mod in getattr(ob, "modifiers", []):
                    if mod.type == 'SURFACE_DEFORM':
                        tgt = getattr(mod, "target", None)
                        if tgt:
                            users_by_target.setdefault(tgt, []).append(ob)
        except Exception:
            users_by_target = {}

        def _is_cloth_object(obj):
            return obj and obj.type == 'MESH' and any(m.type == 'CLOTH' for m in obj.modifiers)

        filtered = []
        for item in scene.jm_cloth_targets:
            obj = getattr(item, "object", None)
            if not obj:
                continue
            if not _is_cloth_object(obj):
                continue
            users = users_by_target.get(obj, [])
            if not users:
                continue
            filtered.append((item, obj, users))

        # ============================
        # Targets used by SurfDeform
        # ============================
        list_box = layout.box()
        hdr = list_box.row()
        hdr.label(text="Jiggle Meshes with Surface Deform", icon='MESH_DATA')

        # 👉 Refresh moved here
        hdr_spacer = list_box.column()
        hdr_spacer.alignment = 'RIGHT'
        hdr_spacer.operator_context = 'INVOKE_DEFAULT'
        hdr_spacer.operator("wm.jm_refresh_cloth_targets", text="Refresh", icon='FILE_REFRESH')

        # ============================
        # Cloth Modifier Visibility
        # ============================
        vbox = hdr_spacer.box()
        vbox.label(text="Cloth Modifier Enable / Disable", icon='MOD_CLOTH')
        row = vbox.row(align=True)
        row.operator("wm.jm_enable_cloth_selected", text="Enable (Selected)", icon='HIDE_OFF')
        row.operator("wm.jm_disable_cloth_selected", text="Disable (Selected)", icon='HIDE_ON')
        row = vbox.row(align=True)
        row.operator("wm.jm_enable_cloth_all", text="Enable (All)", icon='OUTLINER_OB_MESH')
        row.operator("wm.jm_disable_cloth_all", text="Disable (All)", icon='OUTLINER_OB_MESH')

        if not filtered:
            empty = list_box.row()
            empty.alert = True
            empty.label(text="No Cloth objects are used as Surface Deform targets.", icon='ERROR')
            return

        filtered.sort(key=lambda tup: tup[1].name.lower())

#        summary = list_box.row()
#        summary.alignment = 'MIDDLE'
#        summary.label(text=f"{len(filtered)} target(s)")

        for item, obj, users in filtered:
            card = list_box.box()

            top = card.row(align=True)
            top.use_property_split = False

            # Selection checkbox (kept)
            top.prop(item, "selected", text="")

            # 👇 Non-editable object name (replaces editable PointerProperty UI)
            top.enabled = True  # keep the checkbox enabled
            name_row = top.row()
            name_row.enabled = True
            name_row.label(text=obj.name, icon='MESH_DATA')

            # Right-aligned usage badge
            badge = top.row()
            badge.alignment = 'RIGHT'
            badge.enabled = False
            badge.label(text=f"Used by {len(users)}", icon='MOD_MESHDEFORM')

            # Users preview
            names = [u.name for u in users if u]
            preview = ", ".join(names[:4])
            if len(names) > 4:
                preview += f" … (+{len(names) - 4})"

            info = card.row()
            info.enabled = False
            info.use_property_split = False
            info.label(text=f"→ {preview}" if preview else "→ <none>")



# Registration
def register():
    bpy.utils.register_class(ClothBakePanel)

def unregister():
    bpy.utils.unregister_class(ClothBakePanel)

if __name__ == "__main__":
    register()


# === JM Cloth Presets: Operators + Properties =================================
import os, ast, re as _re
import bpy

# Enum for available cloth presets

def _jm_cloth_preset_items(self, context):
    items = []
    try:
        user_dir = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
    except Exception:
        user_dir = None

    if user_dir and os.path.isdir(user_dir):
        for fn in os.listdir(user_dir):
            if fn.endswith(".py"):
                name = os.path.splitext(fn)[0]       # identifier used by Blender
                label = name.replace("_", " ")       # nice label
                items.append((name, label, os.path.join(user_dir, fn)))

    if not items:
        return [("", "<no user presets>", "")]

    # ---- custom ordering -----------------------------------------------------
    # Put these presets at the top in this exact order, if they exist:
    pinned = ["Jiggly"]  # add more, e.g. ["Jiggly", "Firm"]

    def _norm(s: str) -> str:
        # normalize both filenames and 'pinned' entries for robust matching
        return s.casefold().replace("_", " ").strip()

    pinned_rank = { _norm(n): i for i, n in enumerate(pinned) }

    def sort_key(item):
        ident = item[0]           # the filename without .py (Blender item id)
        n = _norm(ident)
        if n in pinned_rank:
            return (0, pinned_rank[n])              # pinned block, keep declared order
        return (1, ident.casefold())                # then alpha by id (case-insensitive)
    # -------------------------------------------------------------------------

    items.sort(key=sort_key)
    return items


def _jm_find_cloth_preset_path(name: str):
    if not name:
        return None
    try:
        user_dir = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
    except Exception:
        user_dir = None
    if user_dir:
        fp = os.path.join(user_dir, f"{name}.py")
        if os.path.exists(fp):
            return fp
    return None

def _jm_apply_cloth_preset_to_settings(settings, preset_name: str):
    if not preset_name:
        return 0, 0
    path = _jm_find_cloth_preset_path(preset_name)
    if not path or not os.path.exists(path):
        return 0, 0

    applied = 0
    skipped = 0
    line_re = _re.compile(r"""^\s*bpy\.context\.cloth\.settings\.([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$""")
    VG_PREFIX = "vertex_group_"  # e.g. vertex_group_mass, vertex_group_bending, ...

    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                m = line_re.match(line)
                if not m:
                    continue

                attr = m.group(1)
                raw = m.group(2).split('#', 1)[0].strip()

                # parse value (string/number/bool/tuple)
                try:
                    val = ast.literal_eval(raw)
                except Exception:
                    try:
                        v = float(raw)
                        val = int(v) if v.is_integer() else v
                    except Exception:
                        skipped += 1
                        continue

                try:
                    # Only apply vertex group fields if the current value is empty
                    if attr.startswith(VG_PREFIX):
                        try:
                            current = getattr(settings, attr)
                        except Exception:
                            current = ""

                        # If already set to a non-empty value, don't overwrite
                        if current:
                            skipped += 1
                            continue

                        # If preset tries to set it to empty anyway, skip
                        if isinstance(val, str) and not val.strip():
                            skipped += 1
                            continue

                    setattr(settings, attr, val)
                    applied += 1
                except Exception:
                    skipped += 1
                    continue
    except Exception:
        return 0, 0

    # Fallback: if the preset left the pin group empty, default to 'Pin'
    try:
        if not getattr(settings, "vertex_group_mass", ""):
            settings.vertex_group_mass = "Pin"
    except Exception:
        pass

    return applied, skipped


def _jm_apply_preset_now(context, preset_name: str):
    """Apply preset to all selected mesh objects' first Cloth modifier (fallback: active)."""
    if not preset_name:
        return

    # Which objects?
    objs = [ob for ob in context.selected_objects if ob.type == 'MESH']
    if not objs and context.object and context.object.type == 'MESH':
        objs = [context.object]

    total_applied = 0
    for ob in objs:
        cloth = next((m for m in ob.modifiers if m.type == 'CLOTH'), None)
        if not cloth:
            continue
        a, s = _jm_apply_cloth_preset_to_settings(cloth.settings, preset_name)
        total_applied += a
        try:
            ob.update_tag(refresh={'DATA'})
        except Exception:
            pass

    # UI refresh (so values show immediately)
    try:
        for area in context.screen.areas:
            area.tag_redraw()
    except Exception:
        pass

    if total_applied == 0:
        print(f"[JM] Preset '{preset_name}' not applied (no cloth settings or nothing changed).")
    else:
        print(f"[JM] Applied preset '{preset_name}' to {len(objs)} object(s); {total_applied} properties set.")

def _jm_on_cloth_preset_changed(self, context):
    # Called automatically when the dropdown value changes
    name = getattr(context.window_manager, "jm_cloth_preset", "") or ""
    _jm_apply_preset_now(context, name)

# WindowManager properties (once)
# Ensure we (re)define the property with update callback so it applies instantly
if hasattr(bpy.types.WindowManager, "jm_cloth_preset"):
    try:
        del bpy.types.WindowManager.jm_cloth_preset
    except Exception:
        pass

bpy.types.WindowManager.jm_cloth_preset = bpy.props.EnumProperty(
    name="Cloth Preset",
    description="Select a Blender cloth preset (applies instantly to selected mesh objects)",
    items=_jm_cloth_preset_items,
    update=_jm_on_cloth_preset_changed,   # ← instant apply on selection
)

if not hasattr(bpy.types.WindowManager, "jm_new_cloth_preset_name"):
    bpy.types.WindowManager.jm_new_cloth_preset_name = bpy.props.StringProperty(
        name="Preset Name", description="Name for the new preset", default="MyPreset", maxlen=64
    )

class JM_OT_ApplyClothPreset(bpy.types.Operator):
    bl_idname = "wm.jm_apply_cloth_preset"
    bl_label = "Apply"
    bl_description = "Apply selected cloth preset to active object's first Cloth modifier"

    def execute(self, context):
        obj = context.object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        cloth = next((m for m in obj.modifiers if m.type == 'CLOTH'), None)
        if not cloth:
            self.report({'WARNING'}, "Active object has no Cloth modifier")
            return {'CANCELLED'}
        name = getattr(context.window_manager, "jm_cloth_preset", "") or ""
        if not name:
            self.report({'WARNING'}, "No preset selected")
            return {'CANCELLED'}
        applied, skipped = _jm_apply_cloth_preset_to_settings(cloth.settings, name)
        for area in context.screen.areas:
            area.tag_redraw()
        if applied == 0:
            self.report({'ERROR'}, "No properties applied (preset may be incompatible)")
            return {'CANCELLED'}
        info = f"Applied {applied}"
        if skipped: info += f", skipped {skipped}"
        self.report({'INFO'}, info)
        return {'FINISHED'}

class JM_OT_SaveClothPreset(bpy.types.Operator):
    bl_idname = "wm.jm_save_cloth_preset"
    bl_label = "Save Current"
    bl_description = "Save current Cloth settings as a user preset (.py)"

    name: bpy.props.StringProperty(name="Preset Name", default="MyPreset")

    def invoke(self, context, event):
        self.name = context.window_manager.jm_new_cloth_preset_name or "MyPreset"
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        self.layout.prop(self, "name", text="Name")

    def execute(self, context):
        obj = context.object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        cloth = next((m for m in obj.modifiers if m.type == 'CLOTH'), None)
        if not cloth:
            self.report({'WARNING'}, "Active object has no Cloth modifier")
            return {'CANCELLED'}
        nm = (self.name or "").strip()
        if not nm:
            self.report({'WARNING'}, "Preset name cannot be empty")
            return {'CANCELLED'}

        try:
            user_dir = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
        except Exception as ex:
            self.report({'ERROR'}, f"Unable to resolve preset folder: {ex}")
            return {'CANCELLED'}
        if not user_dir:
            self.report({'ERROR'}, "Preset folder not available")
            return {'CANCELLED'}

        safe = _re.sub(r"[^A-Za-z0-9_\-]+", "_", nm)
        filepath = os.path.join(user_dir, f"{safe}.py")

        lines = ["import bpy"]
        settings = cloth.settings
        for p in settings.bl_rna.properties:
            if p.is_readonly or p.identifier in {"rna_type"}:
                continue
            try:
                val = getattr(settings, p.identifier)
            except Exception:
                continue
            if hasattr(val, "__len__") and not isinstance(val, (str, bytes)):
                continue
            try:
                lit = repr(val)
            except Exception:
                continue
            lines.append(f"bpy.context.cloth.settings.{p.identifier} = {lit}")

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
        except Exception as ex:
            self.report({'ERROR'}, f"Failed to write preset: {ex}")
            return {'CANCELLED'}

        context.window_manager.jm_new_cloth_preset_name = safe
        for area in context.screen.areas:
            area.tag_redraw()
        self.report({'INFO'}, f"Saved cloth preset: {safe}")
        return {'FINISHED'}

class JM_OT_DeleteClothPreset(bpy.types.Operator):
    bl_idname = "wm.jm_delete_cloth_preset"
    bl_label = "Delete"
    bl_description = "Delete the selected user Cloth preset, Jiggly and Firm can be reinstalled from the plugins preferences Panel."

    def execute(self, context):
        name = getattr(context.window_manager, "jm_cloth_preset", "") or ""
        if not name:
            self.report({'WARNING'}, "No preset selected")
            return {'CANCELLED'}

        # Resolve user dir
        try:
            user_dir = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
        except Exception:
            user_dir = None

        # Gather default preset names (LOCAL and SYSTEM resources)
        default_names = set()
        try:
            for kind in ("LOCAL", "SYSTEM"):
                base = bpy.utils.resource_path(kind)
                if base:
                    sys_dir = os.path.join(base, "scripts", "presets", "cloth")
                    if os.path.isdir(sys_dir):
                        for fn in os.listdir(sys_dir):
                            if fn.endswith(".py"):
                                default_names.add(os.path.splitext(fn)[0])
        except Exception:
            pass

        if name in default_names:
            self.report({'WARNING'}, f"'{name}' is a built-in preset and cannot be deleted.")
            return {'CANCELLED'}

        if not user_dir:
            self.report({'ERROR'}, "User presets folder unavailable")
            return {'CANCELLED'}

        candidate = os.path.realpath(os.path.join(user_dir, f"{name}.py"))
        user_root = os.path.realpath(user_dir)
        try:
            common = os.path.commonpath([user_root, candidate])
        except Exception:
            common = ""

        if common != user_root or not os.path.exists(candidate):
            self.report({'WARNING'}, "Refusing to delete non-user preset")
            return {'CANCELLED'}

        try:
            os.remove(candidate)
        except Exception as ex:
            self.report({'ERROR'}, f"Failed to delete: {ex}")
            return {'CANCELLED'}

        for area in context.screen.areas:
            area.tag_redraw()
        self.report({'INFO'}, f"Deleted cloth preset: {name}")
        return {'FINISHED'}

def _jm_autoregister_cloth_preset_ops():
    _classes = (JM_OT_ApplyClothPreset, JM_OT_SaveClothPreset, JM_OT_DeleteClothPreset)
    for cls in _classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            pass

_jm_autoregister_cloth_preset_ops()
# ============================================================================




