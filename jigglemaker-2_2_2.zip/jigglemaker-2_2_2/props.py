import bpy

class ClothTarget(bpy.types.PropertyGroup):
    object: bpy.props.PointerProperty(type=bpy.types.Object, name="Object")
    selected: bpy.props.BoolProperty(name="Selected", default=False)

def register_props():
    bpy.types.Scene.jm_main = bpy.props.PointerProperty(type=bpy.types.Object, description="Main mesh to receive physics")
    bpy.types.Scene.jm_proxy = bpy.props.PointerProperty(type=bpy.types.Object, description="Proxy mesh used for deform/cloth")
    bpy.types.Scene.jm_proxy_parent_dist = bpy.props.FloatProperty(
        name="Surface Deform Distance", soft_max=0.1, soft_min=0, step=0.01, default=0.015,
        description="Distance threshold to build influence group from proxy to main mesh")
    bpy.types.Scene.jm_bind_armature = bpy.props.BoolProperty(default=True, description="Bind the Proxy mesh to the armature and apply transforms")
    bpy.types.Scene.jm_clean_vgroups = bpy.props.BoolProperty(default=True, description="Remove any unused or invalid vertex groups from the jiggle mesh")
    bpy.types.Scene.jm_cleanup = bpy.props.BoolProperty(default=True, description="Remove artifacts from previous binds (surface deform, pin groups). Does not remove .R version of proxy")
    bpy.types.Scene.jm_add_vertex_group = bpy.props.BoolProperty(default=True, description="Use proxy's pin group (if provided)")
    bpy.types.Scene.jm_surface_deform = bpy.props.BoolProperty(default=True, description="Add a Surface Deform modifier to the main mesh")    
    bpy.types.Scene.jm_add_cloth = bpy.props.BoolProperty(default=True, description="Add a Cloth modifier to proxy object(s)")
    bpy.types.Scene.jm_advanced = bpy.props.BoolProperty(default=False, description="Show advanced settings")
    bpy.types.Scene.jm_mirror_mesh = bpy.props.BoolProperty(default=True, description="Mirror proxy across X to create L/R")

    bpy.types.Scene.jm_trinagulate_deformer = bpy.props.BoolProperty(default=False, description="Add a Triangulate modifier to the jiggle mesh (can help with [target contains concave polygon issue])")

    bpy.types.Object.main_vertex_group = bpy.props.StringProperty(name="Vertex Group Name")
    bpy.types.Object.custom_mesh_vertex_group = bpy.props.StringProperty(name="Vertex Group Name")
    bpy.types.Scene.jm_mode_selector = bpy.props.EnumProperty(
        name="Mode",
        description="Select the jiggle creation mode",
        items=[
            ('OPTION1', "Preset Mode", "Use preset jiggle objects", 'PRESET', 0),
            ('OPTION2', "Vertex Mode", "Apply jiggle to vertex groups", 'VERTEXSEL', 1),
            ('OPTION3', "Custom Mode", "Use your own custom proxy mesh", 'STICKY_UVS_LOC', 2),
        ],
        default='OPTION1')
    # bpy.types.Scene.jm_physics_preset = bpy.props.EnumProperty(
    #     name="Physics Preset",
    #     items=[('OPTION1', 'Jiggly', 'Pinned on edges like breasts'),
    #            ('OPTION2', 'Firm', 'Pinned broadly like belly/thighs')],
    #     default='OPTION1')

    # Readme collapsibles
    bpy.types.Scene.jm_readme_prereq = bpy.props.BoolProperty(name="Prerequisites", default=True)
    bpy.types.Scene.jm_readme_debug_follow = bpy.props.BoolProperty(name="Main mesh not following", default=False)
    bpy.types.Scene.jm_readme_debug_exploding = bpy.props.BoolProperty(name="Proxy exploding", default=False)
    bpy.types.Scene.jm_readme_debug_fall = bpy.props.BoolProperty(name="Proxy falling", default=False)
    bpy.types.Scene.jm_readme_stack = bpy.props.BoolProperty(name="Modifier stack", default=False)
    bpy.types.Scene.jm_readme_changes = bpy.props.BoolProperty(name="Changenotes", default=False)

    # Bake range controls
    bpy.types.Scene.jm_bake_use_range = bpy.props.BoolProperty(
    name="Use Custom Bake Range", default=False,
    description="Bake only within the specified frame range"
    )
    bpy.types.Scene.jm_bake_start = bpy.props.IntProperty(
    name="Bake Start", default=1, min=-100000,
    description="Start frame for cloth bake"
    )
    bpy.types.Scene.jm_bake_end = bpy.props.IntProperty(
    name="Bake End", default=250, min=-100000,
    description="End frame for cloth bake"
    )

    # Cloth bake admin props
    bpy.types.Scene.jm_cloth_targets = bpy.props.CollectionProperty(type=ClothTarget, description="Cloth bake targets")
    bpy.types.Scene.jm_cloth_targets_index = bpy.props.IntProperty(default=0)

def unregister_props():
    del bpy.types.Scene.jm_main
    del bpy.types.Scene.jm_proxy
    del bpy.types.Scene.jm_proxy_parent_dist
    del bpy.types.Scene.jm_bind_armature
    del bpy.types.Scene.jm_cleanup
    del bpy.types.Scene.jm_add_vertex_group
    del bpy.types.Scene.jm_surface_deform
    del bpy.types.Scene.jm_add_cloth
    del bpy.types.Scene.jm_advanced
    del bpy.types.Scene.jm_mirror_mesh
    del bpy.types.Object.main_vertex_group
    del bpy.types.Object.custom_mesh_vertex_group
    del bpy.types.Scene.jm_mode_selector
    #del bpy.types.Scene.jm_physics_preset
    del bpy.types.Scene.jm_bake_use_range
    del bpy.types.Scene.jm_bake_start
    del bpy.types.Scene.jm_bake_end

    del bpy.types.Scene.jm_readme_prereq
    del bpy.types.Scene.jm_readme_debug_follow
    del bpy.types.Scene.jm_readme_debug_exploding
    del bpy.types.Scene.jm_readme_debug_fall
    del bpy.types.Scene.jm_readme_stack
    del bpy.types.Scene.jm_readme_changes

    del bpy.types.Scene.jm_cloth_targets
    del bpy.types.Scene.jm_cloth_targets_index

    del bpy.types.Scene.jm_clean_vgroups
