import bpy
from ..utils import paths

class OpenPluginDirectoryOperator(bpy.types.Operator):
    bl_idname = "wm.open_plugin_directory"
    bl_label = "Open Library File"

    def execute(self, context):
        bpy.ops.wm.path_open(filepath=paths.resources_dir())
        return {'FINISHED'}
